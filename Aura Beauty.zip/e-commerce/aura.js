document.addEventListener('DOMContentLoaded', function() {
    const products = [
        {
            id: 1,
            name: "Glow Serum",
            price: 42.99,
            image: "glowserum.avif"
        },
        {
            id: 2,
            name: "Hydrating Moisturizer",
            price: 32.50,
            image: "moisturizer.avif"
        },
        {
            id: 3,
            name: "Cleansing Oil",
            price: 28.75,
            image: "cleanser.webp"
        },
        {
            id: 4,
            name: "Vitamin C Cream",
            price: 45.00,
            image: "vitaminc.avif"
        },
        {
            id: 5,
            name: "Night Repair Mask",
            price: 38.25,
            image: "mask.webp"
        },
        {
            id: 6,
            name: "Gentle Exfoliator",
            price: 26.99,
            image: "exfoliator.webp"
        },
        {
            id: 7,
            name: "Eye Cream",
            price: 35.50,
            image: "eyecream.webp"
        },
        {
            id: 8,
            name: "Sunscreen SPF 50",
            price: 29.99,
            image: "sunscreen.jpg"
        },
        {
            id: 9,
            name: "Clay Mask",
            price: 24.75,
            image:"claymask.webp"
        },
        {
            id: 10,
            name: "Facial Mist",
            price: 19.99,
            image: "facemist.webp"
        }
    ];

    // Shopping cart
    let cart = [];

    // DOM elements
    const productsContainer = document.querySelector('.products-container');
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');
    const cartCount = document.querySelector('.cart-count');

    // Initialize the page
    function init() {
        renderProducts();
        setEventListeners();
        document.getElementById('home').classList.remove('hidden');
    }

    // Render products to the page
    function renderProducts() {
        productsContainer.innerHTML = products.map(product => `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}" class="product-image">
                <div class="product-info">
                    <h3 class="product-title">${product.name}</h3>
                    <p class="product-price">$${product.price.toFixed(2)}</p>
                    <button class="btn add-to-cart" data-id="${product.id}">Add to Cart</button>
                </div>
            </div>
        `).join('');
    }

    // event listeners
    function setEventListeners() {
        // Navigation
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const sectionToShow = this.getAttribute('data-section');
                showSection(sectionToShow);
            });
        });

        // Add to cart buttons
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('add-to-cart')) {
                const productId = parseInt(e.target.getAttribute('data-id'));
                addToCart(productId);
            }
        });

        // Contact form
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                alert('Thank you for your message! We will get back to you soon.');
                this.reset();
            });
        }
    }

    // Show selected section
    function showSection(sectionId) {
        sections.forEach(section => {
            section.classList.add('hidden');
        });
        document.getElementById(sectionId).classList.remove('hidden');
        window.scrollTo(0, 0);
    }

    // Add product to cart
    function addToCart(productId) {
        const product = products.find(p => p.id === productId);
        if (product) {
            cart.push(product);
            updateCartCount();
            alert(`${product.name} has been added to your cart!`);
        }
    }

    // Update cart count
    function updateCartCount() {
        cartCount.textContent = cart.length;
    }

    // Initialize the page
    init();
});